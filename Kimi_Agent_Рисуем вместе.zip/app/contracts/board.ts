// Shared types & constants for the collaborative board (frontend ↔ backend).

/** Logical canvas size — coordinates are stored in this space on every device. */
export const CANVAS_W = 1600;
export const CANVAS_H = 1000;

/** Colors offered in the toolbar (paper-friendly palette). */
export const BRUSH_COLORS = [
  "#2b2440", // ink
  "#563e79", // deep purple
  "#db3356", // crimson
  "#f28482", // salmon
  "#e9a13b", // amber
  "#84a59d", // sage
  "#6698ff", // soft blue
  "#7a4b2d", // brown
] as const;

/** Colors auto-assigned to participants (presence dots & names). */
export const PRESENCE_COLORS = [
  "#db3356",
  "#6698ff",
  "#84a59d",
  "#e9a13b",
  "#563e79",
  "#f28482",
  "#3d8bfd",
  "#b06ab3",
] as const;

export type StrokePoint = [number, number];

export interface StrokeDto {
  id: number;
  clientId: string;
  authorName: string;
  color: string;
  size: number;
  tool: "brush" | "eraser";
  points: StrokePoint[];
}

export interface ParticipantDto {
  clientId: string;
  name: string;
  color: string;
}

export interface SyncResult {
  /** True when the board was cleared — client must wipe and replay `strokes`. */
  reset: boolean;
  epoch: number;
  strokes: StrokeDto[];
  participants: ParticipantDto[];
}
