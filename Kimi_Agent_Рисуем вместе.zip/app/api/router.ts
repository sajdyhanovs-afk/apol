import { createRouter, publicQuery } from "./middleware";
import { boardRouter } from "./boardRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  board: boardRouter,
});

export type AppRouter = typeof appRouter;
