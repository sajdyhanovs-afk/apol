import { z } from "zod";
import { and, eq, gt, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { rooms, participants, strokes } from "@db/schema";
import { PRESENCE_COLORS } from "@contracts/board";
import type { StrokeDto, SyncResult } from "@contracts/board";
import { TRPCError } from "@trpc/server";

const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no easily-confused chars

function generateCode(length = 6): string {
  let code = "";
  for (let i = 0; i < length; i++) {
    code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  }
  return code;
}

async function findRoomOrThrow(code: string) {
  const room = await getDb().query.rooms.findFirst({
    where: eq(rooms.code, code.toUpperCase()),
  });
  if (!room) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Доска не найдена" });
  }
  return room;
}

/** Presence heartbeat: upsert participant row and refresh lastSeen. */
async function touchParticipant(
  roomId: number,
  clientId: string,
  name?: string,
) {
  const db = getDb();
  const existing = await db.query.participants.findFirst({
    where: and(
      eq(participants.roomId, roomId),
      eq(participants.clientId, clientId),
    ),
  });
  if (existing) {
    await db
      .update(participants)
      .set({ lastSeen: new Date(), ...(name ? { name } : {}) })
      .where(eq(participants.id, existing.id));
    return existing.color;
  }
  // New participant — assign the least-used presence color in this room.
  const peers = await db
    .select({ color: participants.color })
    .from(participants)
    .where(eq(participants.roomId, roomId));
  const color = PRESENCE_COLORS[peers.length % PRESENCE_COLORS.length];
  await db.insert(participants).values({
    roomId,
    clientId,
    name: name || "Гость",
    color,
    lastSeen: new Date(),
  });
  return color;
}

function toStrokeDto(row: typeof strokes.$inferSelect): StrokeDto {
  return {
    id: row.id,
    clientId: row.clientId,
    authorName: row.authorName,
    color: row.color,
    size: row.size,
    tool: row.tool === "eraser" ? "eraser" : "brush",
    points: JSON.parse(row.points),
  };
}

const ACTIVE_WINDOW_SEC = 30;

export const boardRouter = createRouter({
  createRoom: publicQuery
    .input(z.object({ name: z.string().trim().min(1).max(40) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      // Retry a few times in the unlikely case of a code collision.
      for (let attempt = 0; attempt < 5; attempt++) {
        const code = generateCode();
        try {
          const [{ id }] = await db.insert(rooms).values({ code }).$returningId();
          const clientId = crypto.randomUUID();
          await touchParticipant(id, clientId, input.name);
          return { code, clientId };
        } catch (err) {
          if (attempt === 4) throw err;
        }
      }
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    }),

  joinRoom: publicQuery
    .input(
      z.object({
        code: z.string().trim().min(4).max(12),
        clientId: z.string().trim().min(8).max(64),
        name: z.string().trim().min(1).max(40),
      }),
    )
    .mutation(async ({ input }) => {
      const room = await findRoomOrThrow(input.code);
      const color = await touchParticipant(room.id, input.clientId, input.name);
      return { code: room.code, color };
    }),

  addStroke: publicQuery
    .input(
      z.object({
        code: z.string().trim().min(4).max(12),
        clientId: z.string().trim().min(8).max(64),
        color: z.string().trim().max(16),
        size: z.number().int().min(1).max(80),
        tool: z.enum(["brush", "eraser"]),
        points: z.array(z.tuple([z.number(), z.number()])).min(1).max(2000),
      }),
    )
    .mutation(async ({ input }) => {
      const room = await findRoomOrThrow(input.code);
      const me = await getDb().query.participants.findFirst({
        where: and(
          eq(participants.roomId, room.id),
          eq(participants.clientId, input.clientId),
        ),
      });
      const [{ id }] = await getDb()
        .insert(strokes)
        .values({
          roomId: room.id,
          epoch: room.epoch,
          clientId: input.clientId,
          authorName: me?.name ?? "Гость",
          color: input.color,
          size: input.size,
          tool: input.tool,
          points: JSON.stringify(
            input.points.map(
              ([x, y]) =>
                [Math.round(x * 10) / 10, Math.round(y * 10) / 10] as [
                  number,
                  number,
                ],
            ),
          ),
        })
        .$returningId();
      return { id };
    }),

  sync: publicQuery
    .input(
      z.object({
        code: z.string().trim().min(4).max(12),
        clientId: z.string().trim().min(8).max(64),
        afterId: z.number().int().min(0),
        epoch: z.number().int().min(-1),
        name: z.string().trim().min(1).max(40).optional(),
      }),
    )
    .query(async ({ input }): Promise<SyncResult> => {
      const db = getDb();
      const room = await findRoomOrThrow(input.code);
      await touchParticipant(room.id, input.clientId, input.name);

      const reset = room.epoch !== input.epoch;
      const rows = await db
        .select()
        .from(strokes)
        .where(
          reset
            ? and(eq(strokes.roomId, room.id), eq(strokes.epoch, room.epoch))
            : and(eq(strokes.roomId, room.id), gt(strokes.id, input.afterId)),
        )
        .orderBy(strokes.id)
        .limit(500);

      // Compare against the DB's own clock — app/DB servers may have skew.
      const peers = await db
        .select({
          clientId: participants.clientId,
          name: participants.name,
          color: participants.color,
        })
        .from(participants)
        .where(
          and(
            eq(participants.roomId, room.id),
            sql`${participants.lastSeen} >= NOW() - INTERVAL ${ACTIVE_WINDOW_SEC} SECOND`,
          ),
        );

      return {
        reset,
        epoch: room.epoch,
        strokes: rows.map(toStrokeDto),
        participants: peers,
      };
    }),

  clear: publicQuery
    .input(
      z.object({
        code: z.string().trim().min(4).max(12),
        clientId: z.string().trim().min(8).max(64),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const room = await findRoomOrThrow(input.code);
      await db
        .update(rooms)
        .set({ epoch: sql`${rooms.epoch} + 1` })
        .where(eq(rooms.id, room.id));
      await db.delete(strokes).where(eq(strokes.roomId, room.id));
      await touchParticipant(room.id, input.clientId);
      return { epoch: room.epoch + 1 };
    }),
});
