import {
  mysqlTable,
  serial,
  varchar,
  int,
  bigint,
  mediumtext,
  timestamp,
  index,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

export const rooms = mysqlTable(
  "rooms",
  {
    id: serial("id").primaryKey(),
    code: varchar("code", { length: 12 }).notNull(),
    // Bumped every time the board is cleared — clients detect the change and reload.
    epoch: int("epoch").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    codeIdx: uniqueIndex("rooms_code_idx").on(table.code),
  }),
);

export const participants = mysqlTable(
  "participants",
  {
    id: serial("id").primaryKey(),
    roomId: bigint("room_id", { mode: "number", unsigned: true }).notNull(),
    // Stable id generated in the browser (uuid) — distinguishes guests without auth.
    clientId: varchar("client_id", { length: 64 }).notNull(),
    name: varchar("name", { length: 40 }).notNull(),
    color: varchar("color", { length: 16 }).notNull(),
    lastSeen: timestamp("last_seen").notNull().defaultNow(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    roomClientIdx: uniqueIndex("participants_room_client_idx").on(
      table.roomId,
      table.clientId,
    ),
    roomIdx: index("participants_room_idx").on(table.roomId),
  }),
);

export const strokes = mysqlTable(
  "strokes",
  {
    id: serial("id").primaryKey(),
    roomId: bigint("room_id", { mode: "number", unsigned: true }).notNull(),
    epoch: int("epoch").notNull().default(0),
    clientId: varchar("client_id", { length: 64 }).notNull(),
    authorName: varchar("author_name", { length: 40 }).notNull(),
    color: varchar("color", { length: 16 }).notNull(),
    size: int("size").notNull(),
    tool: varchar("tool", { length: 16 }).notNull().default("brush"),
    // JSON array of [x, y] points in logical canvas coordinates.
    points: mediumtext("points").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    roomIdx: index("strokes_room_idx").on(table.roomId, table.id),
  }),
);

export type Room = typeof rooms.$inferSelect;
export type Participant = typeof participants.$inferSelect;
export type Stroke = typeof strokes.$inferSelect;
