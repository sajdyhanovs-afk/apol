import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { saveName, getSavedName, markJoined } from "@/lib/identity";
import { toast } from "sonner";

/* ---- Hand-drawn SVG doodles: thick strokes, white outline, rotated ---- */

function DoodleStar({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none">
      <path
        d="M32 6 L38.5 24 L57 25 L42.5 37 L47 56 L32 45.5 L17 56 L21.5 37 L7 25 L25.5 24 Z"
        fill="#FFCE80"
        stroke="#fff"
        strokeWidth="6"
        strokeLinejoin="round"
      />
      <path
        d="M32 6 L38.5 24 L57 25 L42.5 37 L47 56 L32 45.5 L17 56 L21.5 37 L7 25 L25.5 24 Z"
        stroke="#563E79"
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function DoodleSquiggle({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 40" className={className} fill="none">
      <path
        d="M6 20 Q 21 4, 36 20 T 66 20 T 96 20 T 114 20"
        stroke="#fff"
        strokeWidth="10"
        strokeLinecap="round"
      />
      <path
        d="M6 20 Q 21 4, 36 20 T 66 20 T 96 20 T 114 20"
        stroke="#DB3356"
        strokeWidth="4"
        strokeLinecap="round"
      />
    </svg>
  );
}

function DoodleSpiral({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none">
      <path
        d="M32 32 m0 -4 a4 4 0 0 1 4 4 a8 8 0 0 1 -8 8 a12 12 0 0 1 -12 -12 a16 16 0 0 1 16 -16 a20 20 0 0 1 20 20 a24 24 0 0 1 -24 24"
        stroke="#fff"
        strokeWidth="9"
        strokeLinecap="round"
      />
      <path
        d="M32 32 m0 -4 a4 4 0 0 1 4 4 a8 8 0 0 1 -8 8 a12 12 0 0 1 -12 -12 a16 16 0 0 1 16 -16 a20 20 0 0 1 20 20 a24 24 0 0 1 -24 24"
        stroke="#84A59D"
        strokeWidth="3.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

function DoodleArrow({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 90 60" className={className} fill="none">
      <path
        d="M8 8 Q 40 4, 62 26 M62 26 l-14 -2 M62 26 l-3 -14"
        stroke="#fff"
        strokeWidth="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8 8 Q 40 4, 62 26 M62 26 l-14 -2 M62 26 l-3 -14"
        stroke="#6698FF"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function DoodleHeart({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 60" className={className} fill="none">
      <path
        d="M32 52 C 10 38, 4 24, 12 14 C 19 6, 29 9, 32 18 C 35 9, 45 6, 52 14 C 60 24, 54 38, 32 52 Z"
        fill="#F5CAC3"
        stroke="#fff"
        strokeWidth="6"
        strokeLinejoin="round"
      />
      <path
        d="M32 52 C 10 38, 4 24, 12 14 C 19 6, 29 9, 32 18 C 35 9, 45 6, 52 14 C 60 24, 54 38, 32 52 Z"
        stroke="#563E79"
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function DoodlePencil({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 70 70" className={className} fill="none">
      <g strokeLinejoin="round" strokeLinecap="round">
        <path
          d="M14 56 L20 38 L44 14 L56 26 L32 50 Z"
          fill="#FFCE80"
          stroke="#fff"
          strokeWidth="8"
        />
        <path
          d="M14 56 L20 38 L44 14 L56 26 L32 50 Z"
          stroke="#563E79"
          strokeWidth="2.5"
        />
        <path d="M20 38 L32 50" stroke="#563E79" strokeWidth="2.5" />
        <path
          d="M14 56 L21 48"
          stroke="#563E79"
          strokeWidth="2.5"
        />
      </g>
    </svg>
  );
}

/* ---------------------------------------------------------------------- */

export default function Home() {
  const navigate = useNavigate();
  const [name, setName] = useState(getSavedName());
  const [code, setCode] = useState("");
  const [pending, setPending] = useState(false);
  const createRoom = trpc.board.createRoom.useMutation();

  const handleCreate = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      toast.error("Как тебя подписать на доске? Введи имя");
      return;
    }
    setPending(true);
    try {
      saveName(trimmed);
      const { code, clientId } = await createRoom.mutateAsync({ name: trimmed });
      sessionStorage.setItem("dw:clientId", clientId);
      localStorage.setItem("dw:clientId", clientId);
      markJoined(code);
      navigate(`/board/${code}`);
    } catch {
      toast.error("Не получилось создать доску. Попробуй ещё раз");
      setPending(false);
    }
  };

  const handleJoin = () => {
    const trimmed = code.trim().toUpperCase();
    if (trimmed.length < 4) {
      toast.error("Код доски — 6 символов, он есть в ссылке друга");
      return;
    }
    navigate(`/board/${trimmed}`);
  };

  return (
    <div className="paper-bg min-h-[100dvh] overflow-hidden">
      {/* Floating doodles */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <DoodleStar className="doodle-float absolute left-[6%] top-[14%] w-14 md:w-20 [--rot:-12deg]" />
        <DoodleHeart className="doodle-float absolute right-[8%] top-[18%] w-12 md:w-16 [--rot:10deg] [animation-delay:0.8s]" />
        <DoodleSquiggle className="doodle-float absolute left-[10%] bottom-[22%] w-24 md:w-36 [--rot:6deg] [animation-delay:1.6s]" />
        <DoodleSpiral className="doodle-float absolute right-[12%] bottom-[26%] w-14 md:w-20 [--rot:-8deg] [animation-delay:0.4s]" />
        <DoodleArrow className="doodle-float absolute right-[24%] top-[8%] hidden w-20 md:block [--rot:8deg] [animation-delay:2s]" />
        <DoodlePencil className="doodle-float absolute bottom-[10%] right-[40%] hidden w-16 lg:block [--rot:-16deg] [animation-delay:1.2s]" />
      </div>

      <main className="mx-auto flex min-h-[100dvh] w-full max-w-xl flex-col items-center justify-center px-5 py-12">
        <p className="mb-3 text-sm font-bold uppercase tracking-[0.25em] text-[#DB3356]">
          Общая онлайн-доска
        </p>
        <h1 className="font-display text-center text-4xl leading-tight text-[#563E79] md:text-6xl">
          Рисуем
          <br />
          вместе
        </h1>
        <p className="mt-5 max-w-md text-center text-base font-medium leading-relaxed text-[#563E79]/80 md:text-lg">
          Одна доска для всех друзей: рисуйте, черкайте и устраивайте баттлы
          — прямо в браузере, без регистрации.
        </p>

        {/* Create / join island */}
        <div className="island mt-9 w-full p-5 md:p-7">
          <label className="mb-2 block text-sm font-bold text-[#563E79]">
            Твоё имя на доске
          </label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            placeholder="Например, Маша"
            maxLength={40}
            className="h-12 rounded-xl border-[#e5d9f2] bg-[#faf6ff] text-base font-semibold text-[#563E79] placeholder:text-[#563E79]/40 focus-visible:ring-[#DB3356]"
          />
          <Button
            onClick={handleCreate}
            disabled={pending}
            className="mt-4 h-12 w-full rounded-xl bg-[#DB3356] text-base font-extrabold text-white shadow-none transition-transform hover:bg-[#c22a4a] active:scale-[0.98]"
          >
            {pending ? "Создаём…" : "Создать доску"}
          </Button>

          <div className="my-5 flex items-center gap-3">
            <div className="h-px flex-1 bg-[#563E79]/15" />
            <span className="text-xs font-bold uppercase tracking-widest text-[#563E79]/50">
              или
            </span>
            <div className="h-px flex-1 bg-[#563E79]/15" />
          </div>

          <label className="mb-2 block text-sm font-bold text-[#563E79]">
            Код доски от друга
          </label>
          <div className="flex gap-2">
            <Input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              onKeyDown={(e) => e.key === "Enter" && handleJoin()}
              placeholder="ABC123"
              maxLength={12}
              className="h-12 flex-1 rounded-xl border-[#e5d9f2] bg-[#faf6ff] text-base font-bold tracking-[0.3em] text-[#563E79] placeholder:tracking-[0.3em] placeholder:text-[#563E79]/35 focus-visible:ring-[#84A59D]"
            />
            <Button
              onClick={handleJoin}
              variant="outline"
              className="h-12 rounded-xl border-2 border-[#84A59D] px-5 text-base font-extrabold text-[#4a7a72] hover:bg-[#84A59D]/10 hover:text-[#4a7a72]"
            >
              Войти
            </Button>
          </div>
        </div>

        {/* Pills */}
        <div className="mt-7 flex flex-wrap items-center justify-center gap-2">
          {["Без регистрации", "Одна ссылка для всех", "Работает с телефона"].map(
            (t) => (
              <span
                key={t}
                className="rounded-full bg-[#F5CAC3] px-4 py-1.5 text-xs font-bold text-[#563E79]"
              >
                {t}
              </span>
            ),
          )}
        </div>
      </main>
    </div>
  );
}
