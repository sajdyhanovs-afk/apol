import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  CANVAS_W,
  CANVAS_H,
  BRUSH_COLORS,
  type StrokeDto,
  type StrokePoint,
  type ParticipantDto,
} from "@contracts/board";
import {
  getClientId,
  getSavedName,
  saveName,
  hasJoined,
  markJoined,
} from "@/lib/identity";

const BOARD_BG = "#ffffff";
const SIZES = [
  { label: "S", value: 6 },
  { label: "M", value: 14 },
  { label: "L", value: 30 },
];

type Tool = "brush" | "eraser";

function drawStroke(ctx: CanvasRenderingContext2D, s: StrokeDto) {
  const pts = s.points;
  if (pts.length === 0) return;
  ctx.strokeStyle = s.tool === "eraser" ? BOARD_BG : s.color;
  ctx.fillStyle = ctx.strokeStyle;
  ctx.lineWidth = s.size;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (pts.length === 1) {
    ctx.beginPath();
    ctx.arc(pts[0][0], pts[0][1], s.size / 2, 0, Math.PI * 2);
    ctx.fill();
    return;
  }
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i][0] + pts[i + 1][0]) / 2;
    const my = (pts[i][1] + pts[i + 1][1]) / 2;
    ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
  }
  ctx.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  ctx.stroke();
}

export default function Board() {
  const { code = "" } = useParams<{ code: string }>();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const joinRoom = trpc.board.joinRoom.useMutation();
  const clearBoard = trpc.board.clear.useMutation();

  const [joined, setJoined] = useState(() => hasJoined(code) && !!getSavedName());
  const [nameInput, setNameInput] = useState(getSavedName());
  const [notFound, setNotFound] = useState(false);
  const [participants, setParticipants] = useState<ParticipantDto[]>([]);
  const [color, setColor] = useState<string>(BRUSH_COLORS[0]);
  const [size, setSize] = useState(SIZES[1].value);
  const [tool, setTool] = useState<Tool>("brush");

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);

  const strokesRef = useRef<StrokeDto[]>([]);
  const lastIdRef = useRef(0);
  const epochRef = useRef(-1);
  const ownDrawnRef = useRef<Set<number>>(new Set());
  const drawingRef = useRef<StrokeDto | null>(null);
  const inFlightRef = useRef(false);
  const deadRef = useRef(false);

  const toolRef = useRef(tool);
  const colorRef = useRef(color);
  const sizeRef = useRef(size);
  toolRef.current = tool;
  colorRef.current = color;
  sizeRef.current = size;

  /* ---------- canvas setup & replay ---------- */

  const repaint = useCallback(() => {
    const ctx = ctxRef.current;
    if (!ctx) return;
    ctx.fillStyle = BOARD_BG;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    for (const s of strokesRef.current) drawStroke(ctx, s);
    if (drawingRef.current) drawStroke(ctx, drawingRef.current);
  }, []);

  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const pad = 12;
    const availW = wrap.clientWidth - pad * 2;
    const availH = wrap.clientHeight - pad * 2;
    const displayScale = Math.min(availW / CANVAS_W, availH / CANVAS_H);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const k = displayScale * dpr;
    canvas.width = Math.round(CANVAS_W * k);
    canvas.height = Math.round(CANVAS_H * k);
    canvas.style.width = `${Math.round(CANVAS_W * displayScale)}px`;
    canvas.style.height = `${Math.round(CANVAS_H * displayScale)}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(k, 0, 0, k, 0, 0);
    ctxRef.current = ctx;
    repaint();
  }, [repaint]);

  useEffect(() => {
    setupCanvas();
    const wrap = wrapRef.current;
    if (!wrap) return;
    const ro = new ResizeObserver(setupCanvas);
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [setupCanvas, joined]);

  /* ---------- sync loop ---------- */

  useEffect(() => {
    if (!joined) return;
    deadRef.current = false;
    let timer: ReturnType<typeof setTimeout>;

    const tick = async () => {
      if (deadRef.current || inFlightRef.current) return;
      inFlightRef.current = true;
      try {
        const res = await utils.client.board.sync.query({
          code,
          clientId: getClientId(),
          afterId: lastIdRef.current,
          epoch: epochRef.current,
          name: getSavedName() || undefined,
        });
        if (deadRef.current) return;
        const ctx = ctxRef.current;
        if (res.reset) {
          strokesRef.current = [];
          lastIdRef.current = 0;
          epochRef.current = res.epoch;
          if (ctx) {
            ctx.fillStyle = BOARD_BG;
            ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
          }
        }
        for (const s of res.strokes) {
          lastIdRef.current = Math.max(lastIdRef.current, s.id);
          if (ownDrawnRef.current.has(s.id)) {
            ownDrawnRef.current.delete(s.id); // already on canvas — acknowledge
            continue;
          }
          strokesRef.current.push(s);
          if (ctx) drawStroke(ctx, s);
        }
        setParticipants(res.participants);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "";
        if (msg.includes("NOT_FOUND") || msg.includes("не найдена")) {
          deadRef.current = true;
          setNotFound(true);
          return;
        }
        // transient network error — retry on next tick
      } finally {
        inFlightRef.current = false;
      }
    };

    void tick();
    timer = setInterval(tick, 1500);
    return () => {
      deadRef.current = true;
      clearInterval(timer);
    };
  }, [joined, code, utils]);

  /* ---------- drawing ---------- */

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>): StrokePoint => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * CANVAS_W;
    const y = ((e.clientY - rect.top) / rect.height) * CANVAS_H;
    return [
      Math.max(0, Math.min(CANVAS_W, x)),
      Math.max(0, Math.min(CANVAS_H, y)),
    ];
  };

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const p = getPos(e);
    drawingRef.current = {
      id: -1,
      clientId: getClientId(),
      authorName: getSavedName(),
      color: colorRef.current,
      size: sizeRef.current,
      tool: toolRef.current,
      points: [p],
    };
    if (ctxRef.current) drawStroke(ctxRef.current, drawingRef.current);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const cur = drawingRef.current;
    if (!cur) return;
    const p = getPos(e);
    const last = cur.points[cur.points.length - 1];
    if (Math.hypot(p[0] - last[0], p[1] - last[1]) < 1.5) return;
    cur.points.push(p);
    const ctx = ctxRef.current;
    if (ctx) {
      // incremental segment
      const n = cur.points.length;
      drawStroke(ctx, { ...cur, points: cur.points.slice(Math.max(0, n - 3)) });
    }
  };

  const finishStroke = async () => {
    const cur = drawingRef.current;
    drawingRef.current = null;
    if (!cur || cur.points.length === 0) return;
    const points = cur.points;
    // Downsample very long strokes
    const step = Math.max(1, Math.ceil(points.length / 1900));
    const compact = step === 1 ? points : points.filter((_, i) => i % step === 0);
    try {
      const { id } = await utils.client.board.addStroke.mutate({
        code,
        clientId: getClientId(),
        color: cur.color,
        size: cur.size,
        tool: cur.tool,
        points: compact,
      });
      ownDrawnRef.current.add(id);
      strokesRef.current.push({ ...cur, id, points: compact });
    } catch {
      toast.error("Штрих не сохранился — проверь соединение");
      repaint();
    }
  };

  /* ---------- actions ---------- */

  const handleJoin = async () => {
    const trimmed = nameInput.trim();
    if (!trimmed) {
      toast.error("Введи имя — друзья увидят его на доске");
      return;
    }
    try {
      saveName(trimmed);
      await joinRoom.mutateAsync({ code, clientId: getClientId(), name: trimmed });
      markJoined(code);
      setJoined(true);
    } catch {
      setNotFound(true);
    }
  };

  const handleClear = async () => {
    try {
      const res = await clearBoard.mutateAsync({ code, clientId: getClientId() });
      strokesRef.current = [];
      lastIdRef.current = 0;
      epochRef.current = res.epoch;
      repaint();
      toast.success("Доска очищена");
    } catch {
      toast.error("Не получилось очистить доску");
    }
  };

  const handleShare = async () => {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Ссылка скопирована — отправь друзьям");
    } catch {
      toast.info(url, { duration: 8000 });
    }
  };

  /* ---------- overlays ---------- */

  if (notFound) {
    return (
      <div className="paper-bg flex min-h-[100dvh] items-center justify-center px-5">
        <div className="island w-full max-w-sm p-8 text-center">
          <p className="font-display text-2xl text-[#563E79]">Доска не найдена</p>
          <p className="mt-3 text-sm font-medium text-[#563E79]/70">
            Проверь код в ссылке или создай свою доску.
          </p>
          <Button
            onClick={() => navigate("/")}
            className="mt-6 h-11 w-full rounded-xl bg-[#DB3356] font-extrabold text-white hover:bg-[#c22a4a]"
          >
            На главную
          </Button>
        </div>
      </div>
    );
  }

  if (!joined) {
    return (
      <div className="paper-bg flex min-h-[100dvh] items-center justify-center px-5">
        <div className="island w-full max-w-sm p-6 md:p-8">
          <p className="font-display text-center text-2xl leading-snug text-[#563E79]">
            Тебя позвали
            <br />
            рисовать!
          </p>
          <p className="mt-2 text-center text-sm font-medium text-[#563E79]/70">
            Доска <span className="font-extrabold tracking-[0.2em]">{code}</span>
          </p>
          <label className="mb-2 mt-6 block text-sm font-bold text-[#563E79]">
            Твоё имя
          </label>
          <Input
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleJoin()}
            placeholder="Например, Маша"
            maxLength={40}
            autoFocus
            className="h-12 rounded-xl border-[#e5d9f2] bg-[#faf6ff] text-base font-semibold text-[#563E79] placeholder:text-[#563E79]/40 focus-visible:ring-[#DB3356]"
          />
          <Button
            onClick={handleJoin}
            disabled={joinRoom.isPending}
            className="mt-4 h-12 w-full rounded-xl bg-[#DB3356] text-base font-extrabold text-white hover:bg-[#c22a4a]"
          >
            {joinRoom.isPending ? "Подключаем…" : "К доске!"}
          </Button>
        </div>
      </div>
    );
  }

  /* ---------- board ---------- */

  return (
    <div className="paper-bg fixed inset-0 flex flex-col overflow-hidden">
      {/* canvas area */}
      <div ref={wrapRef} className="relative flex flex-1 items-center justify-center">
        <canvas
          ref={canvasRef}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={finishStroke}
          onPointerCancel={() => (drawingRef.current = null)}
          className="touch-none rounded-xl shadow-[0_0_24px_#00000012] ring-1 ring-[#e8dcc8]"
          style={{ cursor: "crosshair" }}
        />

        {/* top-left: brand + code + share */}
        <div className="island absolute left-3 top-3 flex items-center gap-2 px-3 py-2 md:left-5 md:top-5">
          <span className="font-display hidden text-sm text-[#563E79] sm:block">
            Рисуем вместе
          </span>
          <span className="rounded-lg bg-[#F5CAC3] px-2.5 py-1 text-xs font-extrabold tracking-[0.2em] text-[#563E79]">
            {code}
          </span>
          <button
            onClick={handleShare}
            className="flex h-11 min-w-11 items-center justify-center gap-1.5 rounded-lg bg-[#DB3356] px-3 text-xs font-extrabold text-white transition-colors hover:bg-[#c22a4a]"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7" />
              <path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7" />
            </svg>
            <span className="hidden sm:inline">Позвать друзей</span>
          </button>
        </div>

        {/* top-right: participants */}
        <div className="island absolute right-3 top-3 flex max-w-[45vw] items-center gap-1.5 overflow-x-auto px-2.5 py-2 md:right-5 md:top-5">
          {participants.length === 0 && (
            <span className="px-1 text-xs font-semibold text-[#563E79]/50">…</span>
          )}
          {participants.map((p) => (
            <div
              key={p.clientId}
              title={p.name}
              className="flex h-9 min-w-9 items-center justify-center rounded-full text-xs font-extrabold text-white ring-2 ring-white"
              style={{ backgroundColor: p.color }}
            >
              {p.name.slice(0, 1).toUpperCase()}
            </div>
          ))}
        </div>

        {/* bottom: toolbar */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <div className="island pointer-events-auto flex flex-wrap items-center justify-center gap-x-3 gap-y-2 px-3 py-2.5 md:px-4">
            {/* colors */}
            <div className="flex items-center gap-1">
              {BRUSH_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setColor(c);
                    setTool("brush");
                  }}
                  aria-label={`Цвет ${c}`}
                  className="flex h-11 w-11 items-center justify-center rounded-lg transition-colors hover:bg-[#563E79]/5"
                >
                  <span
                    className={`block h-7 w-7 rounded-full transition-transform ${
                      tool === "brush" && color === c
                        ? "scale-110 ring-2 ring-[#563E79] ring-offset-2"
                        : "ring-1 ring-black/10"
                    }`}
                    style={{ backgroundColor: c }}
                  />
                </button>
              ))}
            </div>

            <div className="hidden h-8 w-px bg-[#563E79]/10 sm:block" />

            {/* sizes */}
            <div className="flex items-center gap-1">
              {SIZES.map((s) => (
                <button
                  key={s.label}
                  onClick={() => setSize(s.value)}
                  aria-label={`Толщина ${s.label}`}
                  className={`flex h-11 w-11 items-center justify-center rounded-lg transition-colors ${
                    size === s.value
                      ? "bg-[#563E79]/10"
                      : "hover:bg-[#563E79]/5"
                  }`}
                >
                  <span
                    className="block rounded-full bg-[#563E79]"
                    style={{
                      width: 6 + s.value / 3.2,
                      height: 6 + s.value / 3.2,
                    }}
                  />
                </button>
              ))}
            </div>

            <div className="hidden h-8 w-px bg-[#563E79]/10 sm:block" />

            {/* eraser */}
            <button
              onClick={() => setTool(tool === "eraser" ? "brush" : "eraser")}
              aria-label="Ластик"
              className={`flex h-11 w-11 items-center justify-center rounded-lg transition-colors ${
                tool === "eraser" ? "bg-[#563E79]/10" : "hover:bg-[#563E79]/5"
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="#563E79" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21" />
                <path d="M22 21H7" />
                <path d="m5 11 9 9" />
              </svg>
            </button>

            {/* clear */}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <button
                  aria-label="Очистить доску"
                  className="flex h-11 w-11 items-center justify-center rounded-lg transition-colors hover:bg-[#DB3356]/10"
                >
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="#DB3356" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 6h18" />
                    <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                    <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                  </svg>
                </button>
              </AlertDialogTrigger>
              <AlertDialogContent className="rounded-2xl">
                <AlertDialogHeader>
                  <AlertDialogTitle className="font-display text-[#563E79]">
                    Очистить всю доску?
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    Рисунки пропадут у всех участников — вернуть их нельзя.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="rounded-xl">Оставить</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleClear}
                    className="rounded-xl bg-[#DB3356] font-bold text-white hover:bg-[#c22a4a]"
                  >
                    Очистить
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </div>
  );
}
