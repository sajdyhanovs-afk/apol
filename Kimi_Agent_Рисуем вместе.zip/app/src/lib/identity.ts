/** Browser identity helpers — no accounts, just a stable client id + nickname. */

const CLIENT_ID_KEY = "dw:clientId";
const NAME_KEY = "dw:name";

export function getClientId(): string {
  let id = localStorage.getItem(CLIENT_ID_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(CLIENT_ID_KEY, id);
  }
  return id;
}

export function getSavedName(): string {
  return localStorage.getItem(NAME_KEY) ?? "";
}

export function saveName(name: string) {
  localStorage.setItem(NAME_KEY, name);
}

const joinedKey = (code: string) => `dw:joined:${code}`;

export function hasJoined(code: string): boolean {
  return sessionStorage.getItem(joinedKey(code)) === "1";
}

export function markJoined(code: string) {
  sessionStorage.setItem(joinedKey(code), "1");
}
